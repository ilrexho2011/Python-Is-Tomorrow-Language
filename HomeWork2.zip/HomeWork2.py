# My favorite song atribute with functions

"""
Use of Functions in Python
"""

def genre():
    Genre = "Heavy metal"
    return  Genre
def artist():
    Artist = "AC/DC"
    return  Artist
def year():
    Year = 1990
    return  Year
def found():
    Found = True
    return Found
print("Artist: " + artist())
print("Genre: " + genre())
print(year())
print(found())