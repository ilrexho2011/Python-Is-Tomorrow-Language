# My favorite song atribute

Album = "The Razor’s Edge"
Title = "Thunderstruck"
Group = "AC/DC"
Genre = "Heavy metal"
Awards = "Juno Award for Recording Engineer of the Year"
Duration = 3.5
Year = 1990
Month = "January"
Date = 10

"""
Use of end=" ", makes possible to print in the same row
with the following print instruction
"""
print("Name of Album: " + Album)
print("Title of Song: " + Title)
print("Artist: " + Group)
print("Genre: " + Genre)
print("Awards: " + Awards)
print(Duration, end=" ")
print("min")
print(Date, end=" ")
print(Month, end=" ")
print(Year)

